// Regular expression to detect URLs
const urlRegex = /\b(\w+DOT\w+(\DOT\w+)*)(\/\S*)?\b/g;

// Function to convert the 'DOT' text to clickable URLs
function convertDOTtoURLs(node) {
  if (node.nodeType === Node.TEXT_NODE && urlRegex.test(node.nodeValue)) {
    let newHTML = node.nodeValue.replace(urlRegex, function (match) {
      let url = match.replace(/DOT/g, '.');
      return `<a href="${url.startsWith('http') ? url : 'http://' + url}" target="_blank">${url}</a>`;
    });
    let div = document.createElement('div');
    div.innerHTML = newHTML;
    while (div.firstChild) {
      node.parentNode.insertBefore(div.firstChild, node);
    }
    node.parentNode.removeChild(node);
  } else {
    node.childNodes.forEach(convertDOTtoURLs);
  }
}

// Mutation observer to monitor changes in the webpage
const observer = new MutationObserver((mutations) => {
  for (let mutation of mutations) {
    if (mutation.type === 'childList') {
      mutation.addedNodes.forEach(convertDOTtoURLs);
    }
  }
});

// Start observing the document
observer.observe(document, {
  childList: true,
  subtree: true
});

// Convert any 'DOT' text already in the document
convertDOTtoURLs(document.body);
